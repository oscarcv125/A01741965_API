export const saludo = (req, res)=>res.send("Hola desde la API 2");
export const pong = (req, res)=>res.send("PONG!");
export const polo = (req, res)=>res.send("POLO!");
export const abc = (req, res)=>res.send("ABC!");